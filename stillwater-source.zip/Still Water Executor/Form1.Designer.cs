﻿namespace Still_Water_Executor
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.Execute = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.Inject = new System.Windows.Forms.Button();
            this.KillRoblox = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.DetectUrls = false;
            this.richTextBox1.EnableAutoDragDrop = true;
            this.richTextBox1.Location = new System.Drawing.Point(12, 12);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(452, 138);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "print(\"still water skibidi toilet\")";
            // 
            // Execute
            // 
            this.Execute.Location = new System.Drawing.Point(12, 156);
            this.Execute.Name = "Execute";
            this.Execute.Size = new System.Drawing.Size(115, 37);
            this.Execute.TabIndex = 1;
            this.Execute.Text = "Execute";
            this.Execute.UseVisualStyleBackColor = true;
            this.Execute.Click += new System.EventHandler(this.Execute_Click);
            // 
            // Clear
            // 
            this.Clear.Location = new System.Drawing.Point(133, 156);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(115, 37);
            this.Clear.TabIndex = 2;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Inject
            // 
            this.Inject.Location = new System.Drawing.Point(470, 12);
            this.Inject.Name = "Inject";
            this.Inject.Size = new System.Drawing.Size(145, 28);
            this.Inject.TabIndex = 3;
            this.Inject.Text = "Inject";
            this.Inject.UseVisualStyleBackColor = true;
            this.Inject.Click += new System.EventHandler(this.Inject_Click);
            // 
            // KillRoblox
            // 
            this.KillRoblox.Location = new System.Drawing.Point(470, 46);
            this.KillRoblox.Name = "KillRoblox";
            this.KillRoblox.Size = new System.Drawing.Size(145, 28);
            this.KillRoblox.TabIndex = 4;
            this.KillRoblox.Text = "Kill Roblox";
            this.KillRoblox.UseVisualStyleBackColor = true;
            this.KillRoblox.Click += new System.EventHandler(this.KillRoblox_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 205);
            this.Controls.Add(this.KillRoblox);
            this.Controls.Add(this.Inject);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Execute);
            this.Controls.Add(this.richTextBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(643, 244);
            this.MinimumSize = new System.Drawing.Size(643, 244);
            this.Name = "Form1";
            this.Opacity = 0.98D;
            this.Text = "Still Water 💧";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button Execute;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.Button Inject;
        private System.Windows.Forms.Button KillRoblox;
    }
}

